# edt_solo
