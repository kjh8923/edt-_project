export default {
  input: 'fetch.js',
  output: {
    file: 'dist/fetch.umd.js',
    format: 'umd',
    name: 'WHATWGFetch'
  }
}
